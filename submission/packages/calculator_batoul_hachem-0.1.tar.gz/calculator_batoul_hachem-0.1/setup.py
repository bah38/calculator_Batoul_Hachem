#!/usr/bin/env python
#   -*- coding: utf-8 -*-

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'calculator_Batoul_Hachem',
        version = '0.1',
        description = 'Lab 6 calculator by Batoul Hachem',
        long_description = '# Lab 6 - Automatic Build\n\n**Student:** Batoul Hachem  \n**Project:** calculator_Batoul_Hachem\n\nThe calculator provides `add`, `subtract`, `multiply`, `divide`, `modulus`,\n`power`, and `square_root`. Division and modulus reject zero divisors with\n`ValueError`; square root rejects negative inputs. Modulus follows Python\'s\nremainder convention (for example, `modulus(-10, 3)` returns `2`).\n\n## Setup and required PyBuilder exercise\n\nUse Python 3.10 or later. From this project directory:\n\n```powershell\npython -m pip install -r requirements.txt\npyb run_unit_tests\npython -m unittest tests.unittest.calculator_Batoul_Hachem.test_calculator_Batoul_Hachem -v\npyb clean install_build_dependencies publish\n```\n\nThe last command cleans previous build output, prepares build dependencies,\nruns all 21 tests, and creates the source archive and wheel under\n`target/dist/calculator_Batoul_Hachem-0.1/dist/`. Running `pyb` alone also\nexecutes `publish`, the default task. PyBuilder manages its own build environment.\nOn this computer `pyb` uses Python 3.13, while `python` uses Python 3.10;\nthe unit tests are checked with both.\n\n`unittest_module_glob` is explicitly set to `test_*`: PyBuilder\'s default\n`*_tests` pattern would miss the lab\'s `test_...py` filenames and run zero tests.\nThe test suite covers all seven functions, zero/negative inputs, fractional\nresults, zero divisors, and invalid square-root inputs.\n\n## Optional Makefile exercise\n\nGNU Make must be installed and available on PATH. The Makefile delegates to\nPyBuilder and uses commands that work on Windows and Unix:\n\n| Command | Purpose |\n| --- | --- |\n| `make install` or `make install_deps` | Install the pinned build tool from requirements.txt. |\n| `make clean` | Remove PyBuilder\'s generated target directory. |\n| `make test` | Run the calculator unit tests through PyBuilder. |\n| `make build` or `make package` | Test and create distributable archives with `pyb publish`. |\n| `make all` or `make` | Clean, install dependencies, test, then package. |\n\nOverride tool commands if necessary, for example `make PYTHON="py -3.13" all`.\nNamed targets replace repeated commands with a consistent build process.\nPhony targets always run; serial execution keeps clean before the build.\nBuild failures propagate to Make rather than reporting success.\n\n## Submission evidence\n\nSee `submission/` for screenshots, original command logs, and the lab report.\nThe required PyBuilder screenshot shows the project base directory, nonzero\ntest count, successful build, and elapsed time. Screenshots capture actual\ncommand runs. The optional Makefile work is included in the same project.\n',
        long_description_content_type = 'text/markdown',
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        keywords = '',

        author = 'Batoul Hachem',
        author_email = '',
        maintainer = '',
        maintainer_email = '',

        license = 'Educational use',

        url = '',
        project_urls = {},

        scripts = [],
        packages = ['calculator_Batoul_Hachem'],
        namespace_packages = [],
        py_modules = [],
        entry_points = {},
        data_files = [],
        package_data = {},
        install_requires = [],
        extras_require = {},
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        python_requires = '',
        obsoletes = [],
    )
